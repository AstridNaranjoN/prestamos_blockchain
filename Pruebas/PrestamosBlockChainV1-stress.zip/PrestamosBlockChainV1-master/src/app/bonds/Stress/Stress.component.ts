import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Bond } from '../../models/bonds/bond.model';
import { Labels } from '../../util/app/appLabels.service';
import { StressService } from './Stress.service';
import { App } from '../../util/app/app.service';
import { DatePipe, CurrencyPipe } from '@angular/common';
import { GoogleAuthService } from '../../util/app/googleAuth.service';
import { Test } from '../../models/Utils/test.model';
import { TestUnit } from '../../models/Utils/testUnit.model';
import { debug } from 'util';


@Component({
    selector: 'stress',
    templateUrl: './Stress.component.html',
    providers: [StressService]
})

export class StressComponent implements OnInit {
    private TotalTestMAX:number = 15000;
    private tests: Test[] = [];
    private testsComplete: Test[] = [];
    private StatusTest: boolean =true;
    private Count:number = 0;
    private TestUnit: TestUnit = new TestUnit();

    constructor(private service: StressService, private app: App, private router: Router, private activeRoute: ActivatedRoute, private googleService: GoogleAuthService) {
    }

    ngOnInit(): void {
        this.tests = [];
        this.TestUnit.Ammount = 0;
        var test1 = new Test();
        test1.Name= "Consultar Bonos";
        test1.NumberExcecutions = 0;
        test1.Ammount= 0;
        test1.ElapsedTime = 0;
        test1.status = true;
        test1.Max = 100;
        var test2 = new Test();
        test2.Name= "Emitir Bonos";
        test2.Ammount= 0;
        test2.NumberExcecutions = 0;
        test2.ElapsedTime = 0;
        test2.status = true;
        test2.Max = 1;

        var test3 = new Test();
        test3.Name= "Mis Bonos";
        test3.Ammount= 0;
        test3.NumberExcecutions = 0;
        test3.ElapsedTime = 0;
        test3.status = true;
        test3.Max = 100;
        
        this.tests.push(test1);
        this.tests.push(test2);
        this.tests.push(test3);
    }

    reiniciar():void{
        this.TestUnit.Ammount = 0;
        this.tests[0].NumberExcecutions = 0;
        this.tests[0].Ammount= 0;
        this.tests[0].ElapsedTime = 0;
        this.tests[0].status = true;

        this.tests[1].NumberExcecutions = 0;
        this.tests[1].Ammount= 0;
        this.tests[1].ElapsedTime = 0;
        this.tests[1].status = true;

        this.tests[2].NumberExcecutions = 0;
        this.tests[2].Ammount= 0;
        this.tests[2].ElapsedTime = 0;
        this.tests[2].status = true;
        
    }

    Prueba(TestNumber:number):void{
        var FechaInicio:Date = new Date;
        if((this.tests[TestNumber].Max == 0 || this.tests[TestNumber].Max > this.TestUnit.Ammount-1) && this.tests[TestNumber].status){
            if(TestNumber == 0){
                this.service.consultarBonos(this.googleService.email).subscribe(
                    result => {
                        this.tests[TestNumber].NumberExcecutions += 1;
                        this.tests[TestNumber].Ammount = result.length;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));
                    }, error => {
                        console.log(error);
                        this.tests[TestNumber].NumberExcecutions += 1;
                        this.tests[TestNumber].status = false;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));                       
                    }
                );
            }
            if(TestNumber == 1){
                this.service.emitirBono().subscribe(
                    result => {
                        this.tests[TestNumber].NumberExcecutions += 1;
                        this.tests[TestNumber].Ammount += 1;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));                        
                    }, error => {
                        console.log(error);
                        this.tests[TestNumber].status = false;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));                        
                    }
                );
            }
            if(TestNumber == 2){
                this.service.misBonos(this.googleService.email).subscribe(
                    result => {
                        this.tests[TestNumber].NumberExcecutions += 1;
                        this.tests[TestNumber].Ammount = result.length;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));

                    }, error => {
                        console.log(error);
                        this.tests[TestNumber].NumberExcecutions += 1;
                        this.tests[TestNumber].status = false;
                        this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                        this.testsComplete.push(this.getNewTest(this.tests[TestNumber]));                        
                    }
                );
            }
        };
    }

    getNewTest(test:Test):Test{
        var newTest = new Test();
        newTest.Name= test.Name;
        newTest.Ammount= test.Ammount;
        newTest.NumberExcecutions = test.NumberExcecutions;
        newTest.ElapsedTime = test.ElapsedTime;
        newTest.status = test.status;
        newTest.Max = test.Max;
        return newTest;
    }

    CicloPruebas():void{
        this.TestUnit.Ammount++;
        this.Prueba(0);
        this.Prueba(1);
        this.Prueba(2);
        if(this.StatusTest){
            if(this.TestUnit.Ammount < this.TotalTestMAX){
                try{
                    setTimeout(this.CicloPruebas(), 0);       
                }catch(e){}
            }
        }

    }


    Iniciar(): void {
        this.reiniciar();
        this.testsComplete=[];
        this.StatusTest = true;
        this.TestUnit.TotalTime = 0;
        this.TestUnit.Ammount = 0;
        this.Count = 0;
        setTimeout(this.CicloPruebas(),0);
    }

    Detener(): void {
        this.StatusTest = false;
    }
}