"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Stress_service_1 = require("./Stress.service");
var app_service_1 = require("../../util/app/app.service");
var googleAuth_service_1 = require("../../util/app/googleAuth.service");
var test_model_1 = require("../../models/Utils/test.model");
var testUnit_model_1 = require("../../models/Utils/testUnit.model");
var StressComponent = (function () {
    function StressComponent(service, app, router, activeRoute, googleService) {
        this.service = service;
        this.app = app;
        this.router = router;
        this.activeRoute = activeRoute;
        this.googleService = googleService;
        this.TotalTestMAX = 15000;
        this.tests = [];
        this.testsComplete = [];
        this.StatusTest = true;
        this.Count = 0;
        this.TestUnit = new testUnit_model_1.TestUnit();
    }
    StressComponent.prototype.ngOnInit = function () {
        this.tests = [];
        this.TestUnit.Ammount = 0;
        var test1 = new test_model_1.Test();
        test1.Name = "Consultar Bonos";
        test1.NumberExcecutions = 0;
        test1.Ammount = 0;
        test1.ElapsedTime = 0;
        test1.status = true;
        test1.Max = 100;
        var test2 = new test_model_1.Test();
        test2.Name = "Emitir Bonos";
        test2.Ammount = 0;
        test2.NumberExcecutions = 0;
        test2.ElapsedTime = 0;
        test2.status = true;
        test2.Max = 1;
        var test3 = new test_model_1.Test();
        test3.Name = "Mis Bonos";
        test3.Ammount = 0;
        test3.NumberExcecutions = 0;
        test3.ElapsedTime = 0;
        test3.status = true;
        test3.Max = 100;
        this.tests.push(test1);
        this.tests.push(test2);
        this.tests.push(test3);
    };
    StressComponent.prototype.reiniciar = function () {
        this.TestUnit.Ammount = 0;
        this.tests[0].NumberExcecutions = 0;
        this.tests[0].Ammount = 0;
        this.tests[0].ElapsedTime = 0;
        this.tests[0].status = true;
        this.tests[1].NumberExcecutions = 0;
        this.tests[1].Ammount = 0;
        this.tests[1].ElapsedTime = 0;
        this.tests[1].status = true;
        this.tests[2].NumberExcecutions = 0;
        this.tests[2].Ammount = 0;
        this.tests[2].ElapsedTime = 0;
        this.tests[2].status = true;
    };
    StressComponent.prototype.Prueba = function (TestNumber) {
        var _this = this;
        var FechaInicio = new Date;
        if ((this.tests[TestNumber].Max == 0 || this.tests[TestNumber].Max > this.TestUnit.Ammount - 1) && this.tests[TestNumber].status) {
            if (TestNumber == 0) {
                this.service.consultarBonos(this.googleService.email).subscribe(function (result) {
                    _this.tests[TestNumber].NumberExcecutions += 1;
                    _this.tests[TestNumber].Ammount = result.length;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                }, function (error) {
                    console.log(error);
                    _this.tests[TestNumber].NumberExcecutions += 1;
                    _this.tests[TestNumber].status = false;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                });
            }
            if (TestNumber == 1) {
                this.service.emitirBono().subscribe(function (result) {
                    _this.tests[TestNumber].NumberExcecutions += 1;
                    _this.tests[TestNumber].Ammount += 1;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                }, function (error) {
                    console.log(error);
                    _this.tests[TestNumber].status = false;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                });
            }
            if (TestNumber == 2) {
                this.service.misBonos(this.googleService.email).subscribe(function (result) {
                    _this.tests[TestNumber].NumberExcecutions += 1;
                    _this.tests[TestNumber].Ammount = result.length;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                }, function (error) {
                    console.log(error);
                    _this.tests[TestNumber].NumberExcecutions += 1;
                    _this.tests[TestNumber].status = false;
                    _this.tests[TestNumber].ElapsedTime = new Date().getTime() - FechaInicio.getTime();
                    _this.testsComplete.push(_this.getNewTest(_this.tests[TestNumber]));
                });
            }
        }
        ;
    };
    StressComponent.prototype.getNewTest = function (test) {
        var newTest = new test_model_1.Test();
        newTest.Name = test.Name;
        newTest.Ammount = test.Ammount;
        newTest.NumberExcecutions = test.NumberExcecutions;
        newTest.ElapsedTime = test.ElapsedTime;
        newTest.status = test.status;
        newTest.Max = test.Max;
        return newTest;
    };
    StressComponent.prototype.CicloPruebas = function () {
        this.TestUnit.Ammount++;
        this.Prueba(0);
        this.Prueba(1);
        this.Prueba(2);
        if (this.StatusTest) {
            if (this.TestUnit.Ammount < this.TotalTestMAX) {
                try {
                    setTimeout(this.CicloPruebas(), 0);
                }
                catch (e) { }
            }
        }
    };
    StressComponent.prototype.Iniciar = function () {
        this.reiniciar();
        this.testsComplete = [];
        this.StatusTest = true;
        this.TestUnit.TotalTime = 0;
        this.TestUnit.Ammount = 0;
        this.Count = 0;
        setTimeout(this.CicloPruebas(), 0);
    };
    StressComponent.prototype.Detener = function () {
        this.StatusTest = false;
    };
    return StressComponent;
}());
StressComponent = __decorate([
    core_1.Component({
        selector: 'stress',
        templateUrl: './Stress.component.html',
        providers: [Stress_service_1.StressService]
    }),
    __metadata("design:paramtypes", [Stress_service_1.StressService, app_service_1.App, router_1.Router, router_1.ActivatedRoute, googleAuth_service_1.GoogleAuthService])
], StressComponent);
exports.StressComponent = StressComponent;
//# sourceMappingURL=Stress.component.js.map