import { Injectable } from '@angular/core';
import { HttpServiceBase } from '../../util/app/httpBase.service'
import { Bond } from '../../models/bonds/bond.model';
import { GoogleAuthService } from '../../util/app/googleAuth.service'

@Injectable()
export class StressService {

    constructor(private httpBase: HttpServiceBase, private googleService: GoogleAuthService) {
    }

    consultarBonos(id: string) {
        return this.httpBase.get('bonds/available/' + id);
    }

    emitirBono() {
        var bond = new Bond();
        bond.interest = 10;
        bond.creationDate = new Date();
        bond.amount = 1000000;
        bond.status = "1";
        bond.installments = 1;
        bond.moneyLenderId = this.googleService.email;
        bond.status = "CREATED"
        return this.httpBase.post('bonds', bond);
    }

    misBonos(id: string) {
        return this.httpBase.get('bonds/loaner/' + id);
   }

    
   
}

