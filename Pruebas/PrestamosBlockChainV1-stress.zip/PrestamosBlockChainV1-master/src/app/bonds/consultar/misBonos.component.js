"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var appLabels_service_1 = require("../../util/app/appLabels.service");
var misBonos_service_1 = require("./misBonos.service");
var app_service_1 = require("../../util/app/app.service");
var googleAuth_service_1 = require("../../util/app/googleAuth.service");
var misBonosComponent = (function () {
    function misBonosComponent(service, app, router, activeRoute, googleService) {
        this.service = service;
        this.app = app;
        this.router = router;
        this.activeRoute = activeRoute;
        this.googleService = googleService;
        this.bonds = [];
        this.labels = new appLabels_service_1.Labels();
        this.currentLabels = this.labels.emitirBono;
    }
    misBonosComponent.prototype.ngOnInit = function () {
        setTimeout(function (component) {
            component.service.misBonos(component.googleService.email).subscribe(function (result) { return component.bonds = result; }, function (error) { return console.log(error); });
        }, 1000, this);
    };
    return misBonosComponent;
}());
misBonosComponent = __decorate([
    core_1.Component({
        selector: 'misBonos',
        templateUrl: './misBonos.component.html',
        providers: [misBonos_service_1.MisBonosService]
    }),
    __metadata("design:paramtypes", [misBonos_service_1.MisBonosService, app_service_1.App, router_1.Router, router_1.ActivatedRoute, googleAuth_service_1.GoogleAuthService])
], misBonosComponent);
exports.misBonosComponent = misBonosComponent;
//# sourceMappingURL=misBonos.component.js.map