"use strict";
var Test = (function () {
    function Test() {
    }
    return Test;
}());
exports.Test = Test;
//# sourceMappingURL=test.model.js.map