export class TestUnit {
    Ammount:number;
    TimeInit:Date;
    NumberExcecutions:number;
    TotalTime:number;
}