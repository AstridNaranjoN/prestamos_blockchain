export class Test {
    ID:number;
    Name: string;
    Ammount: number;
    ElapsedTime: number;
    status: boolean; 
    Max:number
    TimeInit: Date;
    NumberExcecutions:number
    
}