"use strict";
var TestUnit = (function () {
    function TestUnit() {
    }
    return TestUnit;
}());
exports.TestUnit = TestUnit;
//# sourceMappingURL=testUnit.model.js.map