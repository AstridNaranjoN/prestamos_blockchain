"use strict";
var Bond = (function () {
    function Bond() {
    }
    return Bond;
}());
exports.Bond = Bond;
//# sourceMappingURL=bond.model.js.map