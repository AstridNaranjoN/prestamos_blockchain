export class Labels {
    public adquirirBono: any = { fecha: "Fecha Adquisición", valor: "Valor", interes: "Interés", plazo: "Plazo", estado: "Estado", prestatario: "Prestatario", prestamista:"Prestamista", fechaPago: "Fecha de Pago"}
    public emitirBono: any = { fecha: "Fecha Emisión", fechaAdquisicion: "Fecha Adquisición", interes: "Interés", fechaPago: "Fecha de Pago", valor: "Valor", estado: "Estado",prestatario: "Prestatario", prestamista: "Prestamista" }
    public pagarBono: any = { fecha: "Emisión", valor: "Valor", estado: "Estado", interes: "Interes", total: "Valor a Pagar" }
    public registro: any = { nombres: "Nombres y apellidos", email: "Correo electrónico", password: "Contraseña" }
    public login: any = { email: "Correo electrónico", password: "Contraseña" }

} 