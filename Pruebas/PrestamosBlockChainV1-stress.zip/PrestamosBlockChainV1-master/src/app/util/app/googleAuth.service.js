"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var GoogleAuthService = (function () {
    function GoogleAuthService() {
        this.clientId = '742966271455-e09nv94k2o3f2es5d64ga3gi08k1ff5j.apps.googleusercontent.com';
        this.googleInit();
    }
    Object.defineProperty(GoogleAuthService.prototype, "isReady", {
        get: function () {
            if (gapi.auth2 === undefined) {
                return false;
            }
            if (this.auth2 === undefined) {
                return false;
            }
            return true;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GoogleAuthService.prototype, "isSignedIn", {
        get: function () {
            if (!this.isReady) {
                return false;
            }
            return this.auth2.isSignedIn.get();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GoogleAuthService.prototype, "userName", {
        get: function () {
            if (!this.isReady) {
                return '';
            }
            return gapi.auth2.getAuthInstance().currentUser.get().getBasicProfile().getName();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GoogleAuthService.prototype, "email", {
        get: function () {
            if (!this.isReady) {
                return '';
            }
            return gapi.auth2.getAuthInstance().currentUser.get().getBasicProfile().getEmail();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(GoogleAuthService.prototype, "userImage", {
        get: function () {
            if (!this.isReady) {
                return '';
            }
            return gapi.auth2.getAuthInstance().currentUser.get().getBasicProfile().getImageUrl();
        },
        enumerable: true,
        configurable: true
    });
    GoogleAuthService.prototype.googleInit = function () {
        var _this = this;
        if (gapi.auth2 === undefined) {
            gapi.load('auth2', function () {
                if (gapi.auth2.getAuthInstance() === null) {
                    _this.auth2 = gapi.auth2.init({
                        key: 'AIzaSyCoAP7zPEITSLnOZeWPKLnRGQxXm5tObLs',
                        client_id: _this.clientId,
                        cookiepolicy: 'single_host_origin',
                        scope: 'profile email',
                        ux_mode: 'redirect',
                        redirect_uri: 'http://localhost:3081/intermediate'
                    });
                }
                else {
                    _this.auth2 = gapi.auth2.getAuthInstance();
                }
            });
        }
    };
    GoogleAuthService.prototype.signOut = function (callbackFunction) {
        this.auth2.signOut().then(function () { callbackFunction(); });
        this.auth2.disconnect();
    };
    return GoogleAuthService;
}());
GoogleAuthService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [])
], GoogleAuthService);
exports.GoogleAuthService = GoogleAuthService;
//# sourceMappingURL=googleAuth.service.js.map